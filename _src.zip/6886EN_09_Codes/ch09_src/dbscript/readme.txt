Refer to the appropriate readme.txt file for your system in chapter 4 for instructions on how to execute this script.

The following username and password combinations are valid:

dheffel/iforgot
rgonz/secret
